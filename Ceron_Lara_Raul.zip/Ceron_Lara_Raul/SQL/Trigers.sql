-- Primero elimina el trigger existente
DROP TRIGGER trg_valida_pago_inicial;

-- Luego crea el nuevo trigger para la tabla PAGOS
CREATE OR REPLACE TRIGGER trg_valida_pago_inicial
BEFORE INSERT ON pagos
FOR EACH ROW
DECLARE
    v_total_reserva NUMBER(10,2);
    v_total_pagos_previos NUMBER(10,2);
BEGIN
    -- Obtener el total de la reserva
    SELECT total INTO v_total_reserva
    FROM reservas
    WHERE id = :NEW.reserva_id;
    
    -- Calcular suma de pagos existentes para esta reserva
    SELECT NVL(SUM(monto), 0)
    INTO v_total_pagos_previos
    FROM pagos
    WHERE reserva_id = :NEW.reserva_id AND id != :NEW.id;  -- Excluye el pago actual
    
    -- Validar que el pago inicial sea al menos el 30%
    IF (v_total_pagos_previos = 0) AND (:NEW.monto < (v_total_reserva * 0.3)) THEN
        RAISE_APPLICATION_ERROR(-20001, 'El pago inicial debe ser al menos el 30% del total. Total reserva: ' || 
                                       v_total_reserva || ', Pago mínimo requerido: ' || (v_total_reserva * 0.3));
    END IF;
END;
/