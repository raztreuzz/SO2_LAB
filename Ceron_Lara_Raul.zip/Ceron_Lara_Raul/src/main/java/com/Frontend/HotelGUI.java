package com.Frontend;

import com.Frontend.Panels.*;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import java.awt.*;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.PNGTranscoder;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import java.net.URL;

public class HotelGUI extends JFrame {
    private JTabbedPane tabbedPane;
    private static final Color PRIMARY_COLOR = new Color(0, 102, 153); // Azul corporativo
    private static final Color SECONDARY_COLOR = new Color(240, 240, 240); // Fondo claro

    static {
        // Configurar Look and Feel moderno
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
            UIManager.put("TabbedPane.selectedBackground", Color.WHITE);
            UIManager.put("TabbedPane.showTabSeparators", true);
            UIManager.put("Component.arc", 10); // Bordes redondeados
        } catch (Exception ex) {
            System.err.println("Error al configurar FlatLaf");
        }
    }

    public HotelGUI() {
        initUI();
    }

    private void initUI() {
        // Configuración básica de la ventana
        setTitle("Sistema Hotel CUNORI - Gestión de Reservas");
        setSize(1100, 750);
        setMinimumSize(new Dimension(900, 600));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal con márgenes
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        mainPanel.setBackground(SECONDARY_COLOR);

        // Configurar pestañas
        tabbedPane = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        // Cargar ícono de la aplicación
        ImageIcon appIcon = loadIcon("/com/Frontend/assets/hotel.svg", 32);
        if (appIcon != null) {
            setIconImage(appIcon.getImage());
        }

        // Añadir pestañas con iconos
        addTabs();

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(createStatusBar(), BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Mejorar renderizado en Linux/Windows
        setBackground(SECONDARY_COLOR);
        getContentPane().setBackground(SECONDARY_COLOR);
    }

    private void addTabs() {
        // Iconos y paneles para cada pestaña
        tabbedPane.addTab("Reservas", 
            loadIcon("/com/Frontend/assets/reserva.svg", 24), 
            new ReservaPanel());
        
        tabbedPane.addTab("Clientes", 
            loadIcon("/com/Frontend/assets/cliente.svg", 24), 
            new ClientePanel());
        
        tabbedPane.addTab("Habitaciones", 
            loadIcon("/com/Frontend/assets/habitacion.svg", 24), 
            new HabitacionPanel());
        
        // Estilo para pestañas
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            tabbedPane.setBackgroundAt(i, SECONDARY_COLOR);
        }
    }

    private ImageIcon loadIcon(String path, int size) {
        try {
            URL resUrl = getClass().getResource(path);
            if (resUrl == null) {
                System.err.println("Icono no encontrado: " + path);
                return createFallbackIcon(size);
            }

            // Configurar el transcoder SVG
            PNGTranscoder transcoder = new PNGTranscoder();
            transcoder.addTranscodingHint(PNGTranscoder.KEY_WIDTH, (float) size);
            transcoder.addTranscodingHint(PNGTranscoder.KEY_HEIGHT, (float) size);
            
            try (InputStream is = resUrl.openStream()) {
                TranscoderInput input = new TranscoderInput(is);
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                transcoder.transcode(input, new TranscoderOutput(output));
                
                return new ImageIcon(output.toByteArray());
            }
        } catch (Exception e) {
            System.err.println("Error procesando icono SVG:");
            e.printStackTrace();
            return createFallbackIcon(size);
        }
    }

    private ImageIcon createFallbackIcon(int size) {
        // Icono de emergencia (moderno)
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        
        // Fondo circular con color primario
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(PRIMARY_COLOR);
        g2d.fillOval(2, 2, size-4, size-4);
        
        // Letra "H" blanca
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Segoe UI", Font.BOLD, size-10));
        FontMetrics fm = g2d.getFontMetrics();
        g2d.drawString("H", 
            (size - fm.stringWidth("H"))/2, 
            ((size - fm.getHeight())/2) + fm.getAscent());
        
        g2d.dispose();
        return new ImageIcon(img);
    }

    private JPanel createStatusBar() {
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setPreferredSize(new Dimension(getWidth(), 28));
        statusPanel.setBackground(new Color(220, 220, 220));
        
        // Texto de estado
        JLabel statusLabel = new JLabel(" Conectado a Oracle XE | Usuario: admin");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(80, 80, 80));
        
        // Versión
        JLabel versionLabel = new JLabel("v1.0.0 ", SwingConstants.RIGHT);
        versionLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        versionLabel.setForeground(PRIMARY_COLOR);
        
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(versionLabel, BorderLayout.EAST);
        statusPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(200, 200, 200)));
        
        return statusPanel;
    }
}