package com.Frontend.Panels;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.net.URL;
import java.util.List;

import com.controlador.ClienteControlador;
import com.formdev.flatlaf.FlatClientProperties;
import com.modelo.Cliente;

public class ClientePanel extends JPanel {
    private JTable tablaClientes;
    private DefaultTableModel model;
    private JButton btnAgregar, btnEditar, btnEliminar, btnActualizar, btnExportar;
    private JTextField txtBusqueda;
    private static final Color PRIMARY_COLOR = new Color(0, 102, 153);
    private static final Color SECONDARY_COLOR = new Color(240, 240, 240);
    private ClienteControlador controlador = new ClienteControlador();

    public ClientePanel() {
        initComponents();
        setupLayout();
        setupStyles();
        cargarDesdeBaseDeDatos();
    }

    private void initComponents() {
        // Modelo de tabla con columna de acciones
        model = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Apellido", "Email", "Teléfono", "Acciones"}, 
            0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 0 ? Integer.class : Object.class;
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5; // Solo la columna de acciones es editable
            }
        };

        // Configuración avanzada de la tabla
        tablaClientes = new JTable(model);
        tablaClientes.setRowHeight(40);
        tablaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaClientes.setAutoCreateRowSorter(true);
        tablaClientes.setFillsViewportHeight(true);

        // Renderizador personalizado para la columna de acciones
        tablaClientes.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
        tablaClientes.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(new JCheckBox()));

        // Componentes de búsqueda
        txtBusqueda = new JTextField();
        txtBusqueda.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Buscar clientes...");
        txtBusqueda.putClientProperty(FlatClientProperties.TEXT_FIELD_LEADING_ICON, 
            loadIcon("/com/Frontend/assets/search.svg", 16));

        // Botones con iconos
        btnAgregar = createStyledButton("Agregar", "/com/Frontend/assets/user_add.svg");
        btnEditar = createStyledButton("Editar", "/com/Frontend/assets/user_edit.svg");
        btnEliminar = createStyledButton("Eliminar", "/com/Frontend/assets/user_delete.svg");
        btnActualizar = createStyledButton("Actualizar", "/com/Frontend/assets/refresh.svg");
        btnExportar = createStyledButton("Exportar", "/com/Frontend/assets/export.svg");
    }

    private void setupLayout() {
        setLayout(new BorderLayout(0, 0));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(SECONDARY_COLOR);

        // Panel de título y búsqueda
        JPanel headerPanel = new JPanel(new BorderLayout(10, 10));
        headerPanel.setBackground(SECONDARY_COLOR);
        
        JLabel title = new JLabel("GESTIÓN DE CLIENTES");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(PRIMARY_COLOR);
        headerPanel.add(title, BorderLayout.WEST);
        
        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchPanel.setBackground(SECONDARY_COLOR);
        searchPanel.add(txtBusqueda, BorderLayout.CENTER);
        searchPanel.setPreferredSize(new Dimension(300, 30));
        headerPanel.add(searchPanel, BorderLayout.EAST);
        
        add(headerPanel, BorderLayout.NORTH);

        // Tabla con scroll
        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        buttonPanel.setBackground(SECONDARY_COLOR);
        buttonPanel.add(btnExportar);
        buttonPanel.add(btnActualizar);
        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnEditar);
        buttonPanel.add(btnEliminar);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void setupStyles() {
        // Estilo de la tabla
        tablaClientes.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tablaClientes.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tablaClientes.setShowGrid(false);
        tablaClientes.setIntercellSpacing(new Dimension(0, 0));
        tablaClientes.setRowMargin(0);
        
        // Estilo del campo de búsqueda
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        // Listeners para botones
        btnAgregar.addActionListener(this::agregarCliente);
        btnEditar.addActionListener(this::editarCliente);
        btnEliminar.addActionListener(this::eliminarCliente);
        btnActualizar.addActionListener(e -> actualizarTabla());
        btnExportar.addActionListener(this::exportarClientes);
        
        // Listener para búsqueda
        txtBusqueda.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                filtrarClientes(txtBusqueda.getText());
            }
        });
    }

    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        button.setBackground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        
        // Cargar icono si está disponible
        ImageIcon icon = loadIcon(iconPath, 16);
        if (icon != null) {
            button.setIcon(icon);
        }
        
        return button;
    }

    private ImageIcon loadIcon(String path, int size) {
        try {
            URL resUrl = getClass().getResource(path);
            if (resUrl != null) {
                return new ImageIcon(resUrl);
            }
        } catch (Exception e) {
            System.err.println("Error cargando icono: " + e.getMessage());
        }
        return null;
    }

    private void cargarDesdeBaseDeDatos() {
        try {
            model.setRowCount(0);
            List<Cliente> clientes = controlador.listarClientes();
            for (Cliente c : clientes) {
                model.addRow(new Object[]{
                    c.getId(),
                    c.getNombre(),
                    c.getApellido(),
                    c.getEmail(),
                    c.getTelefono(),
                    ""
                });
            }
        } catch (Exception e) {
            mostrarError("Error al cargar clientes desde la base de datos:\n" + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarCliente(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Agregar Nuevo Cliente");
        dialog.setSize(500, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 10, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Campos del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(createFormLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        JTextField txtNombre = createFormTextField();
        panel.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(createFormLabel("Apellido:"), gbc);

        gbc.gridx = 1;
        JTextField txtApellido = createFormTextField();
        panel.add(txtApellido, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(createFormLabel("Email:"), gbc);

        gbc.gridx = 1;
        JTextField txtEmail = createFormTextField();
        panel.add(txtEmail, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(createFormLabel("Teléfono:"), gbc);

        gbc.gridx = 1;
        JTextField txtTelefono = createFormTextField();
        panel.add(txtTelefono, gbc);

        // Botón de guardar
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 0, 0, 0);

        JButton btnGuardar = new JButton("Guardar Cliente");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(PRIMARY_COLOR);
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));

        btnGuardar.addActionListener(ev -> {
            if (validarFormulario(txtNombre, txtApellido, txtEmail, txtTelefono)) {
                Cliente nuevo = new Cliente();
                nuevo.setNombre(txtNombre.getText().trim());
                nuevo.setApellido(txtApellido.getText().trim());
                nuevo.setEmail(txtEmail.getText().trim().toLowerCase());
                nuevo.setTelefono(txtTelefono.getText().trim());

                if (controlador.agregarCliente(nuevo)) {
                    cargarDesdeBaseDeDatos();
                    dialog.dispose();
                    mostrarExito("Cliente agregado exitosamente");
                }
            }
        });

        panel.add(btnGuardar, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void editarCliente(ActionEvent e) {
        int selectedRow = tablaClientes.getSelectedRow();
        if (selectedRow == -1) {
            mostrarAdvertencia("Seleccione un cliente para editar");
            return;
        }
        
        int id = (int) model.getValueAt(selectedRow, 0);
        Cliente cliente = controlador.obtenerCliente(id);
        if (cliente == null) {
            mostrarError("Error al cargar los datos del cliente");
            return;
        }

        JDialog dialog = new JDialog();
        dialog.setTitle("Editar Cliente #" + id);
        dialog.setSize(500, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 10, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Mostrar ID (no editable)
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(createFormLabel("ID:"), gbc);
        
        gbc.gridx = 1;
        JLabel lblId = new JLabel(String.valueOf(id));
        lblId.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panel.add(lblId, gbc);
        
        // Campos editables
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(createFormLabel("Nombre:"), gbc);
        
        gbc.gridx = 1;
        JTextField txtNombre = createFormTextField();
        txtNombre.setText(cliente.getNombre());
        panel.add(txtNombre, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(createFormLabel("Apellido:"), gbc);
        
        gbc.gridx = 1;
        JTextField txtApellido = createFormTextField();
        txtApellido.setText(cliente.getApellido());
        panel.add(txtApellido, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(createFormLabel("Email:"), gbc);
        
        gbc.gridx = 1;
        JTextField txtEmail = createFormTextField();
        txtEmail.setText(cliente.getEmail());
        panel.add(txtEmail, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(createFormLabel("Teléfono:"), gbc);
        
        gbc.gridx = 1;
        JTextField txtTelefono = createFormTextField();
        txtTelefono.setText(cliente.getTelefono());
        panel.add(txtTelefono, gbc);
        
        // Botón de guardar
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 0, 0, 0);
        
        JButton btnGuardar = new JButton("Guardar Cambios");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(PRIMARY_COLOR);
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        btnGuardar.addActionListener(ev -> {
            if (validarFormulario(txtNombre, txtApellido, txtEmail, txtTelefono)) {
                cliente.setNombre(txtNombre.getText().trim());
                cliente.setApellido(txtApellido.getText().trim());
                cliente.setEmail(txtEmail.getText().trim().toLowerCase());
                cliente.setTelefono(txtTelefono.getText().trim());
                
                if (controlador.actualizarCliente(cliente)) {
                    cargarDesdeBaseDeDatos();
                    dialog.dispose();
                    mostrarExito("Cliente actualizado exitosamente");
                }
            }
        });
        
        panel.add(btnGuardar, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void eliminarCliente(ActionEvent e) {
        int selectedRow = tablaClientes.getSelectedRow();
        if (selectedRow == -1) {
            mostrarAdvertencia("Seleccione un cliente para eliminar");
            return;
        }
        
        int id = (int) model.getValueAt(selectedRow, 0);
        String nombreCliente = (String) model.getValueAt(selectedRow, 1);
        String apellidoCliente = (String) model.getValueAt(selectedRow, 2);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar al cliente " + nombreCliente + " " + apellidoCliente + "?", 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (controlador.eliminarCliente(id)) {
                cargarDesdeBaseDeDatos();
                mostrarExito("Cliente eliminado exitosamente");
            }
        }
    }

    private void actualizarTabla() {
        cargarDesdeBaseDeDatos();
        mostrarExito("Lista de clientes actualizada");
    }

    private void exportarClientes(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Exportar Lista de Clientes");
        fileChooser.setSelectedFile(new File("clientes.xlsx"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            JOptionPane.showMessageDialog(this, 
                "Clientes exportados a: " + fileToSave.getAbsolutePath(), 
                "Exportación Exitosa", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void filtrarClientes(String texto) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        tablaClientes.setRowSorter(sorter);
        
        if (texto.trim().length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
        }
    }

    private boolean validarFormulario(JTextField... campos) {
        for (JTextField campo : campos) {
            if (campo.getText().trim().isEmpty()) {
                mostrarError("Todos los campos son obligatorios");
                campo.requestFocus();
                return false;
            }
        }
        
        String email = campos[2].getText().trim();
        if (!email.matches("^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            mostrarError("Por favor ingrese un email válido");
            campos[2].requestFocus();
            return false;
        }
        
        return true;
    }

    // Métodos auxiliares para creación de componentes
    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        return label;
    }

    private JTextField createFormTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }

    // Métodos para mostrar mensajes
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarError(String mensaje, String titulo, int messageType) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, messageType);
    }

    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Advertencia", JOptionPane.WARNING_MESSAGE);
    }

    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    // Renderizador y editor para botones en la tabla
    private class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText("Ver Detalles");
            setBackground(new Color(70, 130, 180));
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.PLAIN, 12));
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }

    private class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private int clickedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            clickedRow = row;
            button.setText("Ver Detalles");
            button.setBackground(new Color(70, 130, 180));
            button.setForeground(Color.WHITE);
            return button;
        }

        public Object getCellEditorValue() {
            if (button.isEnabled()) {
                mostrarDetallesCliente(clickedRow);
            }
            return "";
        }
    }

    private void mostrarDetallesCliente(int row) {
        int id = (int) model.getValueAt(row, 0);
        String nombre = (String) model.getValueAt(row, 1);
        String apellido = (String) model.getValueAt(row, 2);
        String email = (String) model.getValueAt(row, 3);
        String telefono = (String) model.getValueAt(row, 4);
        
        String detalles = String.format(
            "<html><div style='width:300px;padding:10px;'>" +
            "<h3 style='color:%s;text-align:center;'>Detalles del Cliente</h3>" +
            "<p><b>ID:</b> %d<br>" +
            "<b>Nombre:</b> %s %s<br>" +
            "<b>Email:</b> %s<br>" +
            "<b>Teléfono:</b> %s</p>" +
            "</div></html>",
            String.format("#%02x%02x%02x", 
                PRIMARY_COLOR.getRed(), 
                PRIMARY_COLOR.getGreen(), 
                PRIMARY_COLOR.getBlue()),
            id, nombre, apellido, email, telefono
        );
        
        JOptionPane.showMessageDialog(this, 
            detalles, 
            "Detalles del Cliente #" + id, 
            JOptionPane.INFORMATION_MESSAGE);
    }
}