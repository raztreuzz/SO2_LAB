package com.Frontend.Panels;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.List;

import com.controlador.HabitacionControlador;
import com.modelo.Habitacion;
import com.formdev.flatlaf.FlatClientProperties;

public class HabitacionPanel extends JPanel {
    private JTable tablaHabitaciones;
    private DefaultTableModel model;
    private JButton btnAgregar, btnEditar, btnEliminar, btnActualizar;
    private JTextField txtBusqueda;
    private static final Color PRIMARY_COLOR = new Color(0, 102, 153);
    private static final Color SECONDARY_COLOR = new Color(240, 240, 240);
    private HabitacionControlador controlador = new HabitacionControlador();

    public HabitacionPanel() {
        initComponents();
        setupLayout();
        setupStyles();
        cargarDesdeBaseDeDatos();
    }

    private void initComponents() {
        // Modelo de tabla con tipos de datos específicos
        model = new DefaultTableModel(
            new Object[]{"ID", "Tipo", "Precio", "Disponible", "Acciones"}, 
            0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 2 ? Double.class : 
                       columnIndex == 3 ? Boolean.class : 
                       Object.class;
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4; // Solo la columna de acciones es editable
            }
        };

        // Configuración avanzada de la tabla
        tablaHabitaciones = new JTable(model);
        tablaHabitaciones.setRowHeight(40);
        tablaHabitaciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaHabitaciones.setAutoCreateRowSorter(true);
        tablaHabitaciones.setFillsViewportHeight(true);

        // Renderizador personalizado para la columna de disponibilidad
        tablaHabitaciones.getColumnModel().getColumn(3).setCellRenderer(new DisponibilidadRenderer());
        
        // Componentes de búsqueda
        txtBusqueda = new JTextField();
        txtBusqueda.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Buscar habitaciones...");
        txtBusqueda.putClientProperty(FlatClientProperties.TEXT_FIELD_LEADING_ICON, 
            loadIcon("/com/Frontend/assets/search.svg", 16));

        // Botones con iconos
        btnAgregar = createStyledButton("Agregar", "/com/Frontend/assets/add.svg");
        btnEditar = createStyledButton("Editar", "/com/Frontend/assets/edit.svg");
        btnEliminar = createStyledButton("Eliminar", "/com/Frontend/assets/delete.svg");
        btnActualizar = createStyledButton("Actualizar", "/com/Frontend/assets/refresh.svg");
    }

    private void setupLayout() {
        setLayout(new BorderLayout(0, 0));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(SECONDARY_COLOR);

        // Panel de título y búsqueda
        JPanel headerPanel = new JPanel(new BorderLayout(10, 10));
        headerPanel.setBackground(SECONDARY_COLOR);
        
        JLabel title = new JLabel("GESTIÓN DE HABITACIONES");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(PRIMARY_COLOR);
        headerPanel.add(title, BorderLayout.WEST);
        
        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchPanel.setBackground(SECONDARY_COLOR);
        searchPanel.add(txtBusqueda, BorderLayout.CENTER);
        searchPanel.setPreferredSize(new Dimension(300, 30));
        headerPanel.add(searchPanel, BorderLayout.EAST);
        
        add(headerPanel, BorderLayout.NORTH);

        // Tabla con scroll
        JScrollPane scrollPane = new JScrollPane(tablaHabitaciones);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        buttonPanel.setBackground(SECONDARY_COLOR);
        buttonPanel.add(btnActualizar);
        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnEditar);
        buttonPanel.add(btnEliminar);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void setupStyles() {
        // Estilo de la tabla
        tablaHabitaciones.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tablaHabitaciones.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tablaHabitaciones.setShowGrid(false);
        tablaHabitaciones.setIntercellSpacing(new Dimension(0, 0));
        tablaHabitaciones.setRowMargin(0);
        
        // Estilo del campo de búsqueda
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        // Listeners para botones
        btnAgregar.addActionListener(this::agregarHabitacion);
        btnEditar.addActionListener(this::editarHabitacion);
        btnEliminar.addActionListener(this::eliminarHabitacion);
        btnActualizar.addActionListener(e -> actualizarTabla());
        
        // Listener para búsqueda
        txtBusqueda.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                filtrarHabitaciones(txtBusqueda.getText());
            }
        });
    }

    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        button.setBackground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        
        // Cargar icono si está disponible
        ImageIcon icon = loadIcon(iconPath, 16);
        if (icon != null) {
            button.setIcon(icon);
        }
        
        return button;
    }

    private ImageIcon loadIcon(String path, int size) {
        try {
            URL resUrl = getClass().getResource(path);
            if (resUrl != null) {
                return new ImageIcon(resUrl);
            }
        } catch (Exception e) {
            System.err.println("Error cargando icono: " + e.getMessage());
        }
        return null;
    }

    private void cargarDesdeBaseDeDatos() {
        try {
            model.setRowCount(0);
            List<Habitacion> habitaciones = controlador.listarHabitaciones();
            for (Habitacion h : habitaciones) {
                model.addRow(new Object[]{
                    h.getId(),
                    h.getTipo(),
                    h.getPrecio(),
                    h.isDisponible(),
                    ""
                });
            }
        } catch (Exception e) {
            mostrarError("Error al cargar habitaciones desde la base de datos", e);
        }
    }

    private void agregarHabitacion(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Agregar Nueva Habitación");
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 10, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Campos del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(createFormLabel("Tipo:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Individual", "Doble", "Suite"});
        panel.add(cmbTipo, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(createFormLabel("Precio:"), gbc);
        gbc.gridx = 1;
        JTextField txtPrecio = createFormTextField();
        panel.add(txtPrecio, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(createFormLabel("Disponible:"), gbc);
        gbc.gridx = 1;
        JCheckBox chkDisponible = new JCheckBox();
        chkDisponible.setSelected(true);
        panel.add(chkDisponible, gbc);

        // Botón de guardar
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 0, 0, 0);

        JButton btnGuardar = new JButton("Guardar Habitación");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(PRIMARY_COLOR);
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));

        btnGuardar.addActionListener(ev -> {
            try {
                String tipo = (String) cmbTipo.getSelectedItem();
                double precio = Double.parseDouble(txtPrecio.getText());
                boolean disponible = chkDisponible.isSelected();

                Habitacion nueva = new Habitacion();
                nueva.setTipo(tipo);
                nueva.setPrecio(precio);
                nueva.setDisponible(disponible);

                if (controlador.agregarHabitacion(nueva)) {
                    cargarDesdeBaseDeDatos();
                    dialog.dispose();
                    mostrarExito("Habitación agregada exitosamente");
                }
            } catch (NumberFormatException ex) {
                mostrarError("Por favor ingrese un precio válido");
                txtPrecio.requestFocus();
            } catch (Exception ex) {
                mostrarError("Error al agregar habitación", ex);
            }
        });

        panel.add(btnGuardar, gbc);
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void editarHabitacion(ActionEvent e) {
        int selectedRow = tablaHabitaciones.getSelectedRow();
        if (selectedRow == -1) {
            mostrarAdvertencia("Seleccione una habitación para editar");
            return;
        }
        
        int id = (int) model.getValueAt(selectedRow, 0);
        Habitacion habitacion = controlador.obtenerHabitacion(id);
        if (habitacion == null) {
            mostrarError("No se pudo cargar los datos de la habitación");
            return;
        }

        JDialog dialog = new JDialog();
        dialog.setTitle("Editar Habitación #" + id);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 10, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Mostrar ID (no editable)
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(createFormLabel("ID:"), gbc);
        gbc.gridx = 1;
        JLabel lblId = new JLabel(String.valueOf(id));
        lblId.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panel.add(lblId, gbc);
        
        // Campos editables
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(createFormLabel("Tipo:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Individual", "Doble", "Suite"});
        cmbTipo.setSelectedItem(habitacion.getTipo());
        panel.add(cmbTipo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(createFormLabel("Precio:"), gbc);
        gbc.gridx = 1;
        JTextField txtPrecio = createFormTextField();
        txtPrecio.setText(String.valueOf(habitacion.getPrecio()));
        panel.add(txtPrecio, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(createFormLabel("Disponible:"), gbc);
        gbc.gridx = 1;
        JCheckBox chkDisponible = new JCheckBox();
        chkDisponible.setSelected(habitacion.isDisponible());
        panel.add(chkDisponible, gbc);
        
        // Botón de guardar
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 0, 0, 0);
        
        JButton btnGuardar = new JButton("Guardar Cambios");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(PRIMARY_COLOR);
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        btnGuardar.addActionListener(ev -> {
            try {
                habitacion.setTipo((String) cmbTipo.getSelectedItem());
                habitacion.setPrecio(Double.parseDouble(txtPrecio.getText()));
                habitacion.setDisponible(chkDisponible.isSelected());
                
                if (controlador.actualizarHabitacion(habitacion)) {
                    cargarDesdeBaseDeDatos();
                    dialog.dispose();
                    mostrarExito("Habitación actualizada exitosamente");
                }
            } catch (NumberFormatException ex) {
                mostrarError("Por favor ingrese un precio válido");
                txtPrecio.requestFocus();
            } catch (Exception ex) {
                mostrarError("Error al actualizar habitación", ex);
            }
        });
        
        panel.add(btnGuardar, gbc);
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void eliminarHabitacion(ActionEvent e) {
        int selectedRow = tablaHabitaciones.getSelectedRow();
        if (selectedRow == -1) {
            mostrarAdvertencia("Seleccione una habitación para eliminar");
            return;
        }
        
        int id = (int) model.getValueAt(selectedRow, 0);
        String tipo = (String) model.getValueAt(selectedRow, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar la habitación " + id + " (" + tipo + ")?", 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (controlador.eliminarHabitacion(id)) {
                cargarDesdeBaseDeDatos();
                mostrarExito("Habitación eliminada exitosamente");
            }
        }
    }

    private void actualizarTabla() {
        cargarDesdeBaseDeDatos();
        mostrarExito("Lista de habitaciones actualizada");
    }

    private void filtrarHabitaciones(String texto) {
        try {
            if (texto.trim().isEmpty()) {
                cargarDesdeBaseDeDatos();
            } else {
                model.setRowCount(0);
                List<Habitacion> habitaciones = controlador.buscarHabitaciones(texto);
                for (Habitacion h : habitaciones) {
                    model.addRow(new Object[]{
                        h.getId(),
                        h.getTipo(),
                        h.getPrecio(),
                        h.isDisponible(),
                        ""
                    });
                }
            }
        } catch (Exception e) {
            mostrarError("Error al buscar habitaciones", e);
        }
    }

    // Métodos auxiliares para creación de componentes
    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        return label;
    }

    private JTextField createFormTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }

    // Métodos para mostrar mensajes
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarError(String titulo, Exception e) {
        JOptionPane.showMessageDialog(this, 
            titulo + "\nDetalles: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Advertencia", JOptionPane.WARNING_MESSAGE);
    }

    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    // Renderizador personalizado para la columna de disponibilidad
    private class DisponibilidadRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, 
                isSelected, hasFocus, row, column);
            
            if (value instanceof Boolean) {
                boolean disponible = (Boolean) value;
                setText(disponible ? "Disponible" : "Ocupada");
                setForeground(disponible ? new Color(0, 128, 0) : Color.RED);
                setHorizontalAlignment(JLabel.CENTER);
            }
            
            return c;
        }
    }
}