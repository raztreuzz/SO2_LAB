package com.Frontend.Panels;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.Date;
import java.net.URL;

import com.controlador.ReservaControlador;
import com.controlador.ClienteControlador;
import com.controlador.HabitacionControlador;
import com.modelo.Reserva;
import com.modelo.Cliente;
import com.modelo.Habitacion;
import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

public class ReservaPanel extends JPanel {
    private JTextField txtCliente, txtHabitacion, txtFechaInicio, txtFechaFin, txtTotal;
    private JButton btnBuscarCliente, btnBuscarHabitacion, btnConfirmar;
    private JLabel lblClienteId, lblHabitacionId;
    private static final Color PRIMARY_COLOR = new Color(0, 102, 153);
    private static final Color SECONDARY_COLOR = new Color(240, 240, 240);
    
    private ReservaControlador reservaControlador = new ReservaControlador();
    private ClienteControlador clienteControlador = new ClienteControlador();
    private HabitacionControlador habitacionControlador = new HabitacionControlador();
    
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    private NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();

    public ReservaPanel() {
        initComponents();
        setupLayout();
        setupStyles();
    }

    private void initComponents() {
        // Campos de texto con estilo moderno
        txtCliente = createStyledTextField("Seleccione un cliente");
        txtCliente.setEditable(false);
        
        txtHabitacion = createStyledTextField("Seleccione una habitación");
        txtHabitacion.setEditable(false);
        
        txtFechaInicio = createStyledTextField(dateFormat.format(new Date()));
        txtFechaFin = createStyledTextField(dateFormat.format(new Date()));
        
        txtTotal = createStyledTextField(currencyFormat.format(0));
        txtTotal.setEditable(false);

        // Labels ocultos para IDs
        lblClienteId = new JLabel();
        lblClienteId.setVisible(false);
        lblHabitacionId = new JLabel();
        lblHabitacionId.setVisible(false);

        // Botones con iconos y estilo
        btnBuscarCliente = createStyledButton("Buscar Cliente", "/com/Frontend/assets/user_search.svg");
        btnBuscarHabitacion = createStyledButton("Buscar Habitación", "/com/Frontend/assets/bed_search.svg");
        btnConfirmar = createPrimaryButton("Confirmar Reserva", "/com/Frontend/assets/check_circle.svg");
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(20, 20, 20, 20));
        setBackground(SECONDARY_COLOR);

        // Panel de título
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel title = new JLabel("NUEVA RESERVA");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(PRIMARY_COLOR);
        titlePanel.add(title);
        titlePanel.setBackground(SECONDARY_COLOR);
        add(titlePanel, BorderLayout.NORTH);

        // Panel de formulario
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(SECONDARY_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fila 0: Cliente
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(createLabel("Cliente:"), gbc);
        
        gbc.gridx = 1; gbc.weightx = 1;
        formPanel.add(txtCliente, gbc);
        
        gbc.gridx = 2; gbc.weightx = 0;
        formPanel.add(btnBuscarCliente, gbc);
        formPanel.add(lblClienteId, gbc);

        // Fila 1: Habitación
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(createLabel("Habitación:"), gbc);
        
        gbc.gridx = 1;
        formPanel.add(txtHabitacion, gbc);
        
        gbc.gridx = 2;
        formPanel.add(btnBuscarHabitacion, gbc);
        formPanel.add(lblHabitacionId, gbc);

        // Fila 2: Fechas
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(createLabel("Fecha Inicio:"), gbc);
        
        gbc.gridx = 1;
        formPanel.add(txtFechaInicio, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(createLabel("Fecha Fin:"), gbc);
        
        gbc.gridx = 1;
        formPanel.add(txtFechaFin, gbc);

        // Fila 4: Total
        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(createLabel("Total Estimado:"), gbc);
        
        gbc.gridx = 1;
        formPanel.add(txtTotal, gbc);

        add(formPanel, BorderLayout.CENTER);

        // Panel de botón de confirmación
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(SECONDARY_COLOR);
        buttonPanel.add(btnConfirmar);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void setupStyles() {
        // Estilo para los botones de búsqueda
        btnBuscarCliente.addActionListener(this::buscarCliente);
        btnBuscarHabitacion.addActionListener(this::buscarHabitacion);
        btnConfirmar.addActionListener(this::confirmarReserva);
        
        // Listener para calcular total cuando cambian las fechas
        DocumentListener listener = new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { calcularTotal(); }
            public void removeUpdate(DocumentEvent e) { calcularTotal(); }
            public void insertUpdate(DocumentEvent e) { calcularTotal(); }
        };
        
        txtFechaInicio.getDocument().addDocumentListener(listener);
        txtFechaFin.getDocument().addDocumentListener(listener);
    }

    // Métodos auxiliares para creación de componentes
    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return label;
    }

    private JTextField createStyledTextField(String placeholder) {
        JTextField field = new JTextField(20);
        field.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, placeholder);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }

    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        button.setBackground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        
        // Cargar icono si está disponible
        ImageIcon icon = loadIcon(iconPath, 16);
        if (icon != null) {
            button.setIcon(icon);
        }
        
        return button;
    }

    private JButton createPrimaryButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        
        // Cargar icono si está disponible
        ImageIcon icon = loadIcon(iconPath, 18);
        if (icon != null) {
            button.setIcon(icon);
        }
        
        return button;
    }

    private ImageIcon loadIcon(String path, int size) {
        try {
            URL resUrl = getClass().getResource(path);
            if (resUrl != null) {
                return new ImageIcon(resUrl);
            }
        } catch (Exception e) {
            System.err.println("Error cargando icono: " + e.getMessage());
        }
        return null;
    }

    // Métodos de acción
    private void buscarCliente(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Seleccionar Cliente");
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);
        
        // Crear tabla de clientes
        DefaultTableModel model = new DefaultTableModel(new Object[]{"ID", "Nombre", "Apellido", "Email"}, 0);
        JTable tabla = new JTable(model);
        
        // Cargar datos
        try {
            for (Cliente c : clienteControlador.listarClientes()) {
                model.addRow(new Object[]{c.getId(), c.getNombre(), c.getApellido(), c.getEmail()});
            }
        } catch (Exception ex) {
            mostrarError("Error al cargar clientes", ex);
        }
        
        // Configurar selección
        JButton btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.addActionListener(ev -> {
            int row = tabla.getSelectedRow();
            if (row >= 0) {
                int id = (int) model.getValueAt(row, 0);
                String nombre = (String) model.getValueAt(row, 1);
                String apellido = (String) model.getValueAt(row, 2);
                
                lblClienteId.setText(String.valueOf(id));
                txtCliente.setText(nombre + " " + apellido);
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, 
                    "Seleccione un cliente", 
                    "Advertencia", 
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        
        // Configurar layout
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnSeleccionar);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void buscarHabitacion(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Seleccionar Habitación");
        dialog.setSize(700, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);
        
        // Crear tabla de habitaciones
        DefaultTableModel model = new DefaultTableModel(new Object[]{"ID", "Tipo", "Precio", "Disponible"}, 0);
        JTable tabla = new JTable(model);
        
        // Cargar datos
        try {
            for (Habitacion h : habitacionControlador.listarHabitacionesDisponibles()) {
                model.addRow(new Object[]{h.getId(), h.getTipo(), h.getPrecio(), h.isDisponible() ? "Sí" : "No"});
            }
        } catch (Exception ex) {
            mostrarError("Error al cargar habitaciones", ex);
        }
        
        // Configurar selección
        JButton btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.addActionListener(ev -> {
            int row = tabla.getSelectedRow();
            if (row >= 0) {
                int id = (int) model.getValueAt(row, 0);
                String tipo = (String) model.getValueAt(row, 1);
                double precio = (double) model.getValueAt(row, 2);
                
                lblHabitacionId.setText(String.valueOf(id));
                txtHabitacion.setText(tipo + " (#" + id + ") - " + currencyFormat.format(precio));
                calcularTotal();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, 
                    "Seleccione una habitación", 
                    "Advertencia", 
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        
        // Configurar layout
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnSeleccionar);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void calcularTotal() {
        try {
            if (lblHabitacionId.getText().isEmpty()) return;
            
            Date fechaInicio = dateFormat.parse(txtFechaInicio.getText());
            Date fechaFin = dateFormat.parse(txtFechaFin.getText());
            
            if (fechaFin.before(fechaInicio)) {
                txtTotal.setText("Fechas inválidas");
                return;
            }
            
            long diff = fechaFin.getTime() - fechaInicio.getTime();
            int dias = (int) (diff / (1000 * 60 * 60 * 24)) + 1;
            
            int habitacionId = Integer.parseInt(lblHabitacionId.getText());
            Habitacion habitacion = habitacionControlador.obtenerHabitacion(habitacionId);
            
            double total = dias * habitacion.getPrecio();
            txtTotal.setText(currencyFormat.format(total));
            
        } catch (ParseException ex) {
            txtTotal.setText("Formato fecha inválido");
        } catch (Exception ex) {
            txtTotal.setText("Error en cálculo");
        }
    }

    private void confirmarReserva(ActionEvent e) {
        if (!validarCampos()) return;
        
        try {
            int clienteId = Integer.parseInt(lblClienteId.getText());
            int habitacionId = Integer.parseInt(lblHabitacionId.getText());
            Date fechaInicio = dateFormat.parse(txtFechaInicio.getText());
            Date fechaFin = dateFormat.parse(txtFechaFin.getText());
            double total = currencyFormat.parse(txtTotal.getText()).doubleValue();
            
            // Verificar disponibilidad
            if (!reservaControlador.verificarDisponibilidad(habitacionId, fechaInicio, fechaFin)) {
                mostrarError("La habitación no está disponible en las fechas seleccionadas");
                return;
            }
            
            // Mostrar confirmación
            if (mostrarConfirmacion(clienteId, habitacionId, fechaInicio, fechaFin, total)) {
                Reserva reserva = new Reserva();
                reserva.setClienteId(clienteId);
                reserva.setHabitacionId(habitacionId);
                reserva.setFechaInicio(fechaInicio);
                reserva.setFechaFin(fechaFin);
                reserva.setTotal(total);
                reserva.setEstado("CONFIRMADA");
                
                if (reservaControlador.crearReserva(reserva)) {
                    mostrarExito("Reserva registrada exitosamente");
                    limpiarFormulario();
                }
            }
        } catch (ParseException ex) {
            mostrarError("Formato de fecha o moneda inválido");
        } catch (Exception ex) {
            mostrarError("Error al crear reserva", ex);
        }
    }

    private boolean validarCampos() {
        if (lblClienteId.getText().isEmpty()) {
            mostrarError("Seleccione un cliente");
            return false;
        }
        
        if (lblHabitacionId.getText().isEmpty()) {
            mostrarError("Seleccione una habitación");
            return false;
        }
        
        if (txtFechaInicio.getText().trim().isEmpty() || txtFechaFin.getText().trim().isEmpty()) {
            mostrarError("Ingrese ambas fechas");
            return false;
        }
        
        try {
            Date fechaInicio = dateFormat.parse(txtFechaInicio.getText());
            Date fechaFin = dateFormat.parse(txtFechaFin.getText());
            
            if (fechaFin.before(fechaInicio)) {
                mostrarError("La fecha de fin debe ser posterior a la de inicio");
                return false;
            }
            
        } catch (ParseException ex) {
            mostrarError("Formato de fecha inválido (dd/mm/aaaa)");
            return false;
        }
        
        return true;
    }

    private boolean mostrarConfirmacion(int clienteId, int habitacionId, 
                                      Date fechaInicio, Date fechaFin, double total) {
        Cliente cliente = clienteControlador.obtenerCliente(clienteId);
        Habitacion habitacion = habitacionControlador.obtenerHabitacion(habitacionId);
        
        String mensaje = String.format(
            "<html><div style='width:350px;padding:10px;'>" +
            "<h3 style='color:%s;text-align:center;'>Confirmar Reserva</h3>" +
            "<p><b>Cliente:</b> %s %s<br>" +
            "<b>Habitación:</b> %s (#%d)<br>" +
            "<b>Fechas:</b> %s a %s<br>" +
            "<b>Total:</b> %s</p>" +
            "</div></html>",
            String.format("#%02x%02x%02x", 
                PRIMARY_COLOR.getRed(), 
                PRIMARY_COLOR.getGreen(), 
                PRIMARY_COLOR.getBlue()),
            cliente.getNombre(), cliente.getApellido(),
            habitacion.getTipo(), habitacion.getId(),
            dateFormat.format(fechaInicio), dateFormat.format(fechaFin),
            currencyFormat.format(total)
        );

        int opcion = JOptionPane.showOptionDialog(
            this,
            mensaje,
            "Confirmación",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new Object[]{"Confirmar", "Cancelar"},
            "Confirmar"
        );

        return opcion == 0;
    }

    private void limpiarFormulario() {
        lblClienteId.setText("");
        txtCliente.setText("");
        lblHabitacionId.setText("");
        txtHabitacion.setText("");
        txtFechaInicio.setText(dateFormat.format(new Date()));
        txtFechaFin.setText(dateFormat.format(new Date()));
        txtTotal.setText(currencyFormat.format(0));
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarError(String titulo, Exception e) {
        JOptionPane.showMessageDialog(this, 
            titulo + "\nDetalles: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
}