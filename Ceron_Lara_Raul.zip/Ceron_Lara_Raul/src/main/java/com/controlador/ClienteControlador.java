package com.controlador;

import com.modelo.Cliente;
import com.repositorio.ClienteDAO;
import com.repositorio.ClienteDAOimp;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

public class ClienteControlador {
    private final ClienteDAO clienteDAO;
    
    public ClienteControlador() {
        this.clienteDAO = new ClienteDAOimp();
    }
    
    /**
     * Intenta agregar un nuevo cliente al sistema
     * @param cliente El cliente a agregar
     * @return true si se agregó correctamente, false si hubo error
     */
    public boolean agregarCliente(Cliente cliente) {
        try {
            if (cliente == null) {
                throw new IllegalArgumentException("El cliente no puede ser nulo");
            }
            
            if (existeEmail(cliente.getEmail())) {
                throw new IllegalArgumentException("El email " + cliente.getEmail() + " ya está registrado");
            }
            
            clienteDAO.crearCliente(cliente);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al agregar cliente", e);
            return false;
        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return false;
        }
    }
    
    /**
     * Obtiene un cliente por su ID
     * @param id El ID del cliente a buscar
     * @return El cliente encontrado o null si no existe o hay error
     */
    public Cliente obtenerCliente(int id) {
        try {
            if (id <= 0) {
                throw new IllegalArgumentException("ID de cliente inválido");
            }
            return clienteDAO.obtenerClientePorId(id);
        } catch (SQLException e) {
            mostrarError("Error al obtener cliente", e);
            return null;
        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return null;
        }
    }
    
    /**
     * Lista todos los clientes del sistema
     * @return Lista de clientes o lista vacía si hay error
     */
    public List<Cliente> listarClientes() {
        try {
            return clienteDAO.listarTodosClientes();
        } catch (SQLException e) {
            mostrarError("Error al listar clientes", e);
            return List.of();
        }
    }
    
    /**
     * Actualiza los datos de un cliente existente
     * @param cliente El cliente con los datos actualizados
     * @return true si se actualizó correctamente, false si hubo error
     */
    public boolean actualizarCliente(Cliente cliente) {
        try {
            if (cliente == null) {
                throw new IllegalArgumentException("El cliente no puede ser nulo");
            }
            
            Cliente existente = clienteDAO.obtenerClientePorId(cliente.getId());
            if (existente == null) {
                throw new IllegalArgumentException("No se encontró el cliente con ID: " + cliente.getId());
            }
            
            if (!existente.getEmail().equals(cliente.getEmail()) && existeEmail(cliente.getEmail())) {
                throw new IllegalArgumentException("El email " + cliente.getEmail() + " ya está registrado");
            }
            
            clienteDAO.actualizarCliente(cliente);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al actualizar cliente", e);
            return false;
        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return false;
        }
    }
    
    /**
     * Elimina un cliente del sistema
     * @param id El ID del cliente a eliminar
     * @return true si se eliminó correctamente, false si hubo error
     */
    public boolean eliminarCliente(int id) {
        try {
            if (id <= 0) {
                throw new IllegalArgumentException("ID de cliente inválido");
            }
            
            if (clienteDAO.obtenerClientePorId(id) == null) {
                throw new IllegalArgumentException("No se encontró el cliente con ID: " + id);
            }
            
            clienteDAO.eliminarCliente(id);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al eliminar cliente", e);
            return false;
        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return false;
        }
    }
    
    /**
     * Busca clientes que coincidan con el texto proporcionado
     * @param texto Texto para buscar (nombre, apellido, email o teléfono)
     * @return Lista de clientes que coinciden o lista vacía si hay error
     */
    public List<Cliente> buscarClientes(String texto) {
        try {
            if (texto == null || texto.trim().isEmpty()) {
                return listarClientes();
            }
            return clienteDAO.buscarClientes(texto.trim());
        } catch (SQLException e) {
            mostrarError("Error al buscar clientes", e);
            return List.of();
        }
    }
    
    /**
     * Verifica si un email ya está registrado en el sistema
     * @param email El email a verificar
     * @return true si el email existe, false si no existe o hay error
     */
    private boolean existeEmail(String email) throws SQLException {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return !clienteDAO.buscarClientes(email.trim()).isEmpty();
    }
    
    private void mostrarError(String mensaje, Exception e) {
        System.err.println(mensaje + ": " + e.getMessage());
        JOptionPane.showMessageDialog(null, 
            mensaje + "\nDetalles: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(null, 
            mensaje,
            "Advertencia",
            JOptionPane.WARNING_MESSAGE);
    }
}
