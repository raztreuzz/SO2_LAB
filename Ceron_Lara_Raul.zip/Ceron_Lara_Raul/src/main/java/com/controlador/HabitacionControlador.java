package com.controlador;

import com.modelo.Habitacion;
import com.repositorio.HabitacionDAO;
import com.repositorio.HabitacionDAOimp;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

public class HabitacionControlador {
    private final HabitacionDAO habitacionDAO;
    
    public HabitacionControlador() {
        this.habitacionDAO = new HabitacionDAOimp();
    }
    
    public boolean agregarHabitacion(Habitacion habitacion) {
        try {
            habitacionDAO.crearHabitacion(habitacion);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al agregar habitación", e);
            return false;
        }
    }
    
    public Habitacion obtenerHabitacion(int id) {
        try {
            return habitacionDAO.obtenerHabitacionPorId(id);
        } catch (SQLException e) {
            mostrarError("Error al obtener habitación", e);
            return null;
        }
    }
    
    public List<Habitacion> listarHabitaciones() {
        try {
            return habitacionDAO.listarTodasHabitaciones();
        } catch (SQLException e) {
            mostrarError("Error al listar habitaciones", e);
            return List.of();
        }
    }
    
    public List<Habitacion> listarHabitacionesDisponibles() {
        try {
            return habitacionDAO.obtenerHabitacionesDisponibles();
        } catch (SQLException e) {
            mostrarError("Error al listar habitaciones disponibles", e);
            return List.of();
        }
    }
    
    public boolean actualizarHabitacion(Habitacion habitacion) {
        try {
            habitacionDAO.actualizarHabitacion(habitacion);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al actualizar habitación", e);
            return false;
        }
    }
    
    public boolean eliminarHabitacion(int id) {
        try {
            habitacionDAO.eliminarHabitacion(id);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al eliminar habitación", e);
            return false;
        }
    }
    
    public List<Habitacion> buscarHabitaciones(String texto) {
        try {
            return habitacionDAO.buscarHabitaciones(texto);
        } catch (SQLException e) {
            mostrarError("Error al buscar habitaciones", e);
            return List.of();
        }
    }
    
    private void mostrarError(String mensaje, Exception e) {
        System.err.println(mensaje + ": " + e.getMessage());
        JOptionPane.showMessageDialog(null, 
            mensaje + "\nDetalles: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
}