package com.controlador;

import com.modelo.Reserva;
import com.repositorio.ReservaDAO;
import com.repositorio.ReservaDAOimp;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ReservaControlador {
    private final ReservaDAO reservaDAO;
    
    public ReservaControlador() {
        this.reservaDAO = new ReservaDAOimp();
    }
    
    public boolean crearReserva(Reserva reserva) {
        try {
            if (!reservaDAO.verificarDisponibilidad(reserva.getHabitacionId(), 
                                                   reserva.getFechaInicio(), 
                                                   reserva.getFechaFin())) {
                throw new IllegalArgumentException("La habitación no está disponible en las fechas seleccionadas");
            }
            
            reservaDAO.crearReserva(reserva);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al crear reserva", e);
            return false;
        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return false;
        }
    }
    
    public Reserva obtenerReserva(int id) {
        try {
            return reservaDAO.obtenerReservaPorId(id);
        } catch (SQLException e) {
            mostrarError("Error al obtener reserva", e);
            return null;
        }
    }
    
    public List<Reserva> listarReservas() {
        try {
            return reservaDAO.listarTodasReservas();
        } catch (SQLException e) {
            mostrarError("Error al listar reservas", e);
            return List.of();
        }
    }
    
    public boolean actualizarReserva(Reserva reserva) {
        try {
            if (!reservaDAO.verificarDisponibilidad(reserva.getHabitacionId(), 
                                                   reserva.getFechaInicio(), 
                                                   reserva.getFechaFin())) {
                // Excluir la reserva actual de la verificación
                Reserva existente = reservaDAO.obtenerReservaPorId(reserva.getId());
                if (existente == null || existente.getHabitacionId() != reserva.getHabitacionId() ||
                    !solapanFechas(existente.getFechaInicio(), existente.getFechaFin(),
                                  reserva.getFechaInicio(), reserva.getFechaFin())) {
                    throw new IllegalArgumentException("La habitación no está disponible en las fechas seleccionadas");
                }
            }
            
            reservaDAO.actualizarReserva(reserva);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al actualizar reserva", e);
            return false;
        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return false;
        }
    }
    
    public boolean eliminarReserva(int id) {
        try {
            reservaDAO.eliminarReserva(id);
            return true;
        } catch (SQLException e) {
            mostrarError("Error al eliminar reserva", e);
            return false;
        }
    }
    
    public List<Reserva> buscarReservas(String texto) {
        try {
            return reservaDAO.buscarReservas(texto);
        } catch (SQLException e) {
            mostrarError("Error al buscar reservas", e);
            return List.of();
        }
    }
    
    public List<Reserva> obtenerReservasPorCliente(int clienteId) {
        try {
            return reservaDAO.obtenerReservasPorCliente(clienteId);
        } catch (SQLException e) {
            mostrarError("Error al obtener reservas del cliente", e);
            return List.of();
        }
    }
    
    public List<Reserva> obtenerReservasPorHabitacion(int habitacionId) {
        try {
            return reservaDAO.obtenerReservasPorHabitacion(habitacionId);
        } catch (SQLException e) {
            mostrarError("Error al obtener reservas de la habitación", e);
            return List.of();
        }
    }
    
    public boolean verificarDisponibilidad(int habitacionId, Date fechaInicio, Date fechaFin) {
        try {
            return reservaDAO.verificarDisponibilidad(habitacionId, fechaInicio, fechaFin);
        } catch (SQLException e) {
            mostrarError("Error al verificar disponibilidad", e);
            return false;
        }
    }
    
    private boolean solapanFechas(Date inicio1, Date fin1, Date inicio2, Date fin2) {
        return !(fin1.before(inicio2) || fin2.before(inicio1));
    }
    
    private void mostrarError(String mensaje, Exception e) {
        System.err.println(mensaje + ": " + e.getMessage());
        JOptionPane.showMessageDialog(null, 
            mensaje + "\nDetalles: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(null, 
            mensaje,
            "Advertencia",
            JOptionPane.WARNING_MESSAGE);
    }
}