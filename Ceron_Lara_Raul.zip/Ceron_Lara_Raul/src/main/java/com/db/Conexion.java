// Source code is decompiled from a .class file using FernFlower decompiler.
package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
   public Conexion() {
   }

   public static Connection getConnection() {
      String DRIVER = "oracle.jdbc.driver.OracleDriver";
      String URL = "jdbc:oracle:thin:@//192.168.56.100:1521/XEPDB1";
      String USER = "raul";
      String PASS = "root123";
      Connection conexion = null;

      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         conexion = DriverManager.getConnection("jdbc:oracle:thin:@//192.168.56.100:1521/XEPDB1", "raul", "root123");
         System.out.println("Conexión exitosa a Oracle XEPDB1");
      } catch (ClassNotFoundException var6) {
         System.err.println("Error: Driver no encontrado");
         var6.printStackTrace();
      } catch (SQLException var7) {
         System.err.println("Error de conexión:");
         System.err.println("URL: jdbc:oracle:thin:@//192.168.56.100:1521/XEPDB1");
         System.err.println("Usuario: raul");
         var7.printStackTrace();
         if (var7.getErrorCode() == 12505) {
            System.err.println("\nSOLUCIÓN: Verifica que:");
            System.err.println("1. XEPDB1 esté registrado en el listener");
            System.err.println("2. El servicio Oracle esté activo");
            System.err.println("3. Credenciales sean correctas");
         }
      }

      return conexion;
   }

   public static void closeConnection(Connection conn) {
      try {
         if (conn != null && !conn.isClosed()) {
            conn.close();
            System.out.println("Conexión cerrada");
         }
      } catch (SQLException var2) {
         System.err.println("Error al cerrar conexión:");
         var2.printStackTrace();
      }

   }
}
