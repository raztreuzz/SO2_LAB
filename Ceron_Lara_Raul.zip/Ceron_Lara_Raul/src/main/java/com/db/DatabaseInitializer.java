package com.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseInitializer {
    
    public static void inicializarBaseDatos(boolean forzarRecreacion) {
        try (Connection conn = Conexion.getConnection()) {
            conn.setAutoCommit(false); // Desactivar autocommit para usar transacciones
            
            try {
                if (forzarRecreacion) {
                    eliminarTablas(conn);
                }
                
                if (!tablasExisten(conn)) {
                    crearTablas(conn);
                    insertarDatosIniciales(conn);
                }
                
                conn.commit(); // Confirmar la transacción si todo va bien
                System.out.println("Base de datos inicializada correctamente");
                
            } catch (SQLException e) {
                conn.rollback(); // Revertir en caso de error
                System.err.println("Error al inicializar la base de datos: " + e.getMessage());
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("Error grave al conectar con la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static boolean tablasExisten(Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME IN ('CLIENTES', 'HABITACIONES', 'RESERVAS')";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
             
            return rs.next() && rs.getInt(1) == 3;
        }
    }

    private static void eliminarTablas(Connection conn) throws SQLException {
        // Orden importante por las restricciones de clave foránea
        String[] tablas = {"RESERVAS", "HABITACIONES", "CLIENTES"};
        
        for (String tabla : tablas) {
            try {
                conn.createStatement().execute("DROP TABLE " + tabla + " CASCADE CONSTRAINTS");
                System.out.println("Tabla " + tabla + " eliminada correctamente");
            } catch (SQLException e) {
                if (!e.getMessage().contains("ORA-00942")) { // Ignorar error si la tabla no existe
                    throw e;
                }
            }
        }
    }

    private static void crearTablas(Connection conn) throws SQLException {
        List<String> sentencias = new ArrayList<>();
        
        // Creación de tablas
        sentencias.add(
            "CREATE TABLE CLIENTES (" +
            "id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, " +
            "nombre VARCHAR2(100) NOT NULL, " +
            "apellido VARCHAR2(100) NOT NULL, " +
            "email VARCHAR2(100) UNIQUE NOT NULL, " +
            "telefono VARCHAR2(20))"
        );
        
        sentencias.add(
            "CREATE TABLE HABITACIONES (" +
            "id NUMBER PRIMARY KEY, " +
            "tipo VARCHAR2(50) NOT NULL, " +
            "precio NUMBER(10,2) NOT NULL, " +
            "disponible NUMBER(1) DEFAULT 1)"
        );
        
        sentencias.add(
            "CREATE TABLE RESERVAS (" +
            "id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, " +
            "cliente_id NUMBER NOT NULL, " +
            "habitacion_id NUMBER NOT NULL, " +
            "fecha_inicio DATE NOT NULL, " +
            "fecha_fin DATE NOT NULL, " +
            "total NUMBER(10,2) NOT NULL, " +
            "FOREIGN KEY (cliente_id) REFERENCES CLIENTES(id), " +
            "FOREIGN KEY (habitacion_id) REFERENCES HABITACIONES(id))"
        );
        
        // Índices para mejorar rendimiento
        sentencias.add("CREATE INDEX IDX_RESERVAS_CLIENTE ON RESERVAS(cliente_id)");
        sentencias.add("CREATE INDEX IDX_RESERVAS_HABITACION ON RESERVAS(habitacion_id)");
        
        // Ejecutar todas las sentencias
        try (Statement stmt = conn.createStatement()) {
            for (String sql : sentencias) {
                try {
                    stmt.execute(sql);
                    System.out.println("Ejecutado: " + sql.split("\\(")[0] + "...");
                } catch (SQLException e) {
                    if (!e.getMessage().contains("ORA-00955")) { // Ignorar error si la tabla ya existe
                        throw e;
                    }
                }
            }
        }
    }

    private static void insertarDatosIniciales(Connection conn) throws SQLException {
        // Insertar habitaciones
        String[] insertsHabitaciones = {
            "INSERT INTO HABITACIONES (id, tipo, precio) VALUES (101, 'Individual', 100.0)",
            "INSERT INTO HABITACIONES (id, tipo, precio) VALUES (102, 'Individual', 100.0)",
            "INSERT INTO HABITACIONES (id, tipo, precio) VALUES (201, 'Doble', 150.0)",
            "INSERT INTO HABITACIONES (id, tipo, precio) VALUES (202, 'Doble', 150.0)",
            "INSERT INTO HABITACIONES (id, tipo, precio) VALUES (301, 'Suite', 250.0)",
            "INSERT INTO HABITACIONES (id, tipo, precio) VALUES (302, 'Suite Deluxe', 350.0)"
        };
        
        try (Statement stmt = conn.createStatement()) {
            for (String sql : insertsHabitaciones) {
                try {
                    stmt.execute(sql);
                } catch (SQLException e) {
                    if (!e.getMessage().contains("ORA-00001")) { // Ignorar error de duplicado
                        throw e;
                    }
                }
            }
            System.out.println("Datos iniciales de habitaciones insertados");
        }
        
        
    }
    
    public static void inicializarBaseDatos() {
        inicializarBaseDatos(false);
    }
}