package com.modelo;

public class Cliente {
    private int id;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;

    // Constructores
    public Cliente() {}

    public Cliente(int id, String nombre, String apellido, String email, String telefono) {
        setId(id);
        setNombre(nombre);
        setApellido(apellido);
        setEmail(email);
        setTelefono(telefono);
    }

    // Getters y Setters con validaciones básicas
    public int getId() {
        return id;
    }

    public void setId(int id) {
        if(id < 0) {
            throw new IllegalArgumentException("ID no puede ser negativo");
        }
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Nombre es requerido");
        }
        this.nombre = nombre.trim();
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        if(apellido == null || apellido.trim().isEmpty()) {
            throw new IllegalArgumentException("Apellido es requerido");
        }
        this.apellido = apellido.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if(email == null || !email.matches("^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            throw new IllegalArgumentException("Email no válido");
        }
        this.email = email.toLowerCase().trim();
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        if(telefono == null || telefono.trim().isEmpty()) {
            throw new IllegalArgumentException("Teléfono es requerido");
        }
        this.telefono = telefono.trim();
    }

    @Override
    public String toString() {
        return String.format("Cliente[id=%d, nombre=%s, apellido=%s, email=%s]", 
            id, nombre, apellido, email);
    }
}