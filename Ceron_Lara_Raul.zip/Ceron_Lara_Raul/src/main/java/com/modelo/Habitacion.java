package com.modelo;


public class Habitacion {
    private int id;
    private String tipo;
    private double precio;
    private boolean disponible;

    // Constructores
    public Habitacion() {}

    public Habitacion(int id, String tipo, double precio, boolean disponible) {
        this.id = id;
        this.tipo = tipo;
        this.precio = precio;
        this.disponible = disponible;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if(id <= 0) {
            throw new IllegalArgumentException("ID debe ser positivo");
        }
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if(tipo == null || !tipo.matches("Individual|Doble|Suite")) {
            throw new IllegalArgumentException("Tipo debe ser Individual, Doble o Suite");
        }
        this.tipo = tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if(precio <= 0) {
            throw new IllegalArgumentException("Precio debe ser mayor a 0");
        }
        this.precio = precio;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    @Override
    public String toString() {
        return String.format("Habitacion[id=%d, tipo=%s, precio=%.2f, disponible=%s]",
            id, tipo, precio, disponible ? "Sí" : "No");
    }
}