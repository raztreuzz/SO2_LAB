package com.modelo;

import java.util.Date;

public class Reserva {
    private int id;
    private int clienteId;
    private int habitacionId;
    private Date fechaInicio;
    private Date fechaFin;
    private double total;
    private String estado; // "CONFIRMADA", "CANCELADA", etc.

    // Constructores
    public Reserva() {}

    public Reserva(int id, int clienteId, int habitacionId, Date fechaInicio, Date fechaFin, double total, String estado) {
        this.id = id;
        this.clienteId = clienteId;
        this.habitacionId = habitacionId;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.total = total;
        this.estado = estado;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public int getHabitacionId() {
        return habitacionId;
    }

    public void setHabitacionId(int habitacionId) {
        this.habitacionId = habitacionId;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return String.format("Reserva[id=%d, clienteId=%d, habitacionId=%d, %s a %s, total=%.2f, estado=%s]",
            id, clienteId, habitacionId, fechaInicio, fechaFin, total, estado);
    }
}