package com.repositorio;

import com.modelo.Cliente;
import java.util.List;
import java.sql.SQLException;

public interface ClienteDAO {
    void crearCliente(Cliente cliente) throws SQLException;
    Cliente obtenerClientePorId(int id) throws SQLException;
    List<Cliente> listarTodosClientes() throws SQLException;
    void actualizarCliente(Cliente cliente) throws SQLException;
    void eliminarCliente(int id) throws SQLException;
    List<Cliente> buscarClientes(String texto) throws SQLException;
}