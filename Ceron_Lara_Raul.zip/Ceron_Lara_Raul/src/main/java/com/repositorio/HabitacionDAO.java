package com.repositorio;

import com.modelo.Habitacion;
import java.sql.SQLException;
import java.util.List;

public interface HabitacionDAO {
    void crearHabitacion(Habitacion habitacion) throws SQLException;
    Habitacion obtenerHabitacionPorId(int id) throws SQLException;
    List<Habitacion> listarTodasHabitaciones() throws SQLException;
    void actualizarHabitacion(Habitacion habitacion) throws SQLException;
    void eliminarHabitacion(int id) throws SQLException;
    List<Habitacion> buscarHabitaciones(String texto) throws SQLException;
    List<Habitacion> obtenerHabitacionesDisponibles() throws SQLException;
}