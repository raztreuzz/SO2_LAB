package com.repositorio;

import com.modelo.Habitacion;
import com.db.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HabitacionDAOimp implements HabitacionDAO {

    @Override
    public void crearHabitacion(Habitacion habitacion) throws SQLException {
        String sql = "INSERT INTO habitaciones (id, tipo, precio, disponible) VALUES (seq_habitaciones.NEXTVAL, ?, ?, ?)";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, new String[]{"id"})) {
            
            stmt.setString(1, habitacion.getTipo());
            stmt.setDouble(2, habitacion.getPrecio());
            stmt.setInt(3, habitacion.isDisponible() ? 1 : 0);
            
            stmt.executeUpdate();
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    habitacion.setId(generatedKeys.getInt(1));
                }
            }
        }
    }

    @Override
    public Habitacion obtenerHabitacionPorId(int id) throws SQLException {
        String sql = "SELECT * FROM habitaciones WHERE id = ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearHabitacion(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Habitacion> listarTodasHabitaciones() throws SQLException {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT * FROM habitaciones ORDER BY tipo, precio";
        
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                habitaciones.add(mapearHabitacion(rs));
            }
        }
        return habitaciones;
    }

    @Override
    public void actualizarHabitacion(Habitacion habitacion) throws SQLException {
        String sql = "UPDATE habitaciones SET tipo = ?, precio = ?, disponible = ? WHERE id = ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, habitacion.getTipo());
            stmt.setDouble(2, habitacion.getPrecio());
            stmt.setInt(3, habitacion.isDisponible() ? 1 : 0);
            stmt.setInt(4, habitacion.getId());
            
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminarHabitacion(int id) throws SQLException {
        String sql = "DELETE FROM habitaciones WHERE id = ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Habitacion> buscarHabitaciones(String texto) throws SQLException {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT * FROM habitaciones WHERE LOWER(tipo) LIKE ? OR CAST(precio AS VARCHAR) LIKE ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            String parametroBusqueda = "%" + texto.toLowerCase() + "%";
            stmt.setString(1, parametroBusqueda);
            stmt.setString(2, parametroBusqueda);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    habitaciones.add(mapearHabitacion(rs));
                }
            }
        }
        return habitaciones;
    }

    @Override
    public List<Habitacion> obtenerHabitacionesDisponibles() throws SQLException {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT * FROM habitaciones WHERE disponible = 1 ORDER BY tipo, precio";
        
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                habitaciones.add(mapearHabitacion(rs));
            }
        }
        return habitaciones;
    }

    private Habitacion mapearHabitacion(ResultSet rs) throws SQLException {
        Habitacion habitacion = new Habitacion();
        habitacion.setId(rs.getInt("id"));
        habitacion.setTipo(rs.getString("tipo"));
        habitacion.setPrecio(rs.getDouble("precio"));
        habitacion.setDisponible(rs.getInt("disponible") == 1);
        return habitacion;
    }
}