package com.repositorio;

import com.modelo.Reserva;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public interface ReservaDAO {
    void crearReserva(Reserva reserva) throws SQLException;
    Reserva obtenerReservaPorId(int id) throws SQLException;
    List<Reserva> listarTodasReservas() throws SQLException;
    void actualizarReserva(Reserva reserva) throws SQLException;
    void eliminarReserva(int id) throws SQLException;
    List<Reserva> buscarReservas(String texto) throws SQLException;
    List<Reserva> obtenerReservasPorCliente(int clienteId) throws SQLException;
    List<Reserva> obtenerReservasPorHabitacion(int habitacionId) throws SQLException;
    boolean verificarDisponibilidad(int habitacionId, Date fechaInicio, Date fechaFin) throws SQLException;
}