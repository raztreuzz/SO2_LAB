package com.repositorio;

import com.modelo.Reserva;
import com.db.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReservaDAOimp implements ReservaDAO {

    @Override
    public void crearReserva(Reserva reserva) throws SQLException {
        String sql = "INSERT INTO reservas (id, cliente_id, habitacion_id, fecha_inicio, fecha_fin, total) " +
                     "VALUES (seq_reservas.NEXTVAL, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, new String[]{"id"})) {
            
            stmt.setInt(1, reserva.getClienteId());
            stmt.setInt(2, reserva.getHabitacionId());
            stmt.setDate(3, new java.sql.Date(reserva.getFechaInicio().getTime()));
            stmt.setDate(4, new java.sql.Date(reserva.getFechaFin().getTime()));
            stmt.setDouble(5, reserva.getTotal());
            
            stmt.executeUpdate();
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    reserva.setId(generatedKeys.getInt(1));
                }
            }
        }
    }

    @Override
    public Reserva obtenerReservaPorId(int id) throws SQLException {
        String sql = "SELECT * FROM reservas WHERE id = ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearReserva(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Reserva> listarTodasReservas() throws SQLException {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * FROM reservas ORDER BY fecha_inicio DESC";
        
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                reservas.add(mapearReserva(rs));
            }
        }
        return reservas;
    }

    @Override
    public void actualizarReserva(Reserva reserva) throws SQLException {
        String sql = "UPDATE reservas SET cliente_id = ?, habitacion_id = ?, " +
                     "fecha_inicio = ?, fecha_fin = ?, total = ? WHERE id = ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reserva.getClienteId());
            stmt.setInt(2, reserva.getHabitacionId());
            stmt.setDate(3, new java.sql.Date(reserva.getFechaInicio().getTime()));
            stmt.setDate(4, new java.sql.Date(reserva.getFechaFin().getTime()));
            stmt.setDouble(5, reserva.getTotal());
            stmt.setInt(6, reserva.getId());
            
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminarReserva(int id) throws SQLException {
        String sql = "DELETE FROM reservas WHERE id = ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Reserva> buscarReservas(String texto) throws SQLException {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT r.* FROM reservas r " +
                     "JOIN clientes c ON r.cliente_id = c.id " +
                     "JOIN habitaciones h ON r.habitacion_id = h.id " +
                     "WHERE LOWER(c.nombre) LIKE ? OR LOWER(c.apellido) LIKE ? " +
                     "OR LOWER(h.tipo) LIKE ? OR CAST(r.id AS VARCHAR) LIKE ?";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            String parametroBusqueda = "%" + texto.toLowerCase() + "%";
            stmt.setString(1, parametroBusqueda);
            stmt.setString(2, parametroBusqueda);
            stmt.setString(3, parametroBusqueda);
            stmt.setString(4, parametroBusqueda);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservas.add(mapearReserva(rs));
                }
            }
        }
        return reservas;
    }

    @Override
    public List<Reserva> obtenerReservasPorCliente(int clienteId) throws SQLException {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * FROM reservas WHERE cliente_id = ? ORDER BY fecha_inicio DESC";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, clienteId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservas.add(mapearReserva(rs));
                }
            }
        }
        return reservas;
    }

    @Override
    public List<Reserva> obtenerReservasPorHabitacion(int habitacionId) throws SQLException {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * FROM reservas WHERE habitacion_id = ? ORDER BY fecha_inicio DESC";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, habitacionId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservas.add(mapearReserva(rs));
                }
            }
        }
        return reservas;
    }

    @Override
    public boolean verificarDisponibilidad(int habitacionId, Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT COUNT(*) FROM reservas " +
                     "WHERE habitacion_id = ? " +
                     "AND ((fecha_inicio BETWEEN ? AND ?) " +
                     "OR (fecha_fin BETWEEN ? AND ?) " +
                     "OR (? BETWEEN fecha_inicio AND fecha_fin) " +
                     "OR (? BETWEEN fecha_inicio AND fecha_fin))";
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, habitacionId);
            stmt.setDate(2, new java.sql.Date(fechaInicio.getTime()));
            stmt.setDate(3, new java.sql.Date(fechaFin.getTime()));
            stmt.setDate(4, new java.sql.Date(fechaInicio.getTime()));
            stmt.setDate(5, new java.sql.Date(fechaFin.getTime()));
            stmt.setDate(6, new java.sql.Date(fechaInicio.getTime()));
            stmt.setDate(7, new java.sql.Date(fechaFin.getTime()));
            
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) == 0;
            }
        }
    }

    private Reserva mapearReserva(ResultSet rs) throws SQLException {
        Reserva reserva = new Reserva();
        reserva.setId(rs.getInt("id"));
        reserva.setClienteId(rs.getInt("cliente_id"));
        reserva.setHabitacionId(rs.getInt("habitacion_id"));
        reserva.setFechaInicio(rs.getDate("fecha_inicio"));
        reserva.setFechaFin(rs.getDate("fecha_fin"));
        reserva.setTotal(rs.getDouble("total"));
        return reserva;
    }
}