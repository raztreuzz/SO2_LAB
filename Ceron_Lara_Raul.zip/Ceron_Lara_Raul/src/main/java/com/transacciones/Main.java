package com.transacciones;

import com.Frontend.HotelGUI;
import com.db.DatabaseInitializer;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // 1. Configuración inicial del sistema
        configureSystemProperties();

        DatabaseInitializer.inicializarBaseDatos();
        
        // 2. Inicialización segura de Swing
        SwingUtilities.invokeLater(() -> {
            try {
                initializeApplication();
            } catch (Exception e) {
                showFatalError(e);
            }
        });
    }

    private static void configureSystemProperties() {
        // Para evitar problemas con OpenJDK y Swing
        System.setProperty("sun.awt.xembedserver", "true");
        System.setProperty("java.awt.headless", "false");
    }

    private static void initializeApplication() {
        // Configurar Look and Feel nativo
        setNativeLookAndFeel();
        
        // Iniciar ventana principal
        HotelGUI mainWindow = new HotelGUI();
        mainWindow.setVisible(true);
        
        // Mostrar estado inicial
        JOptionPane.showMessageDialog(mainWindow,
            "Sistema conectado a Oracle 21c XE\nVersión 1.0",
            "Inicio exitoso",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private static void setNativeLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("Error al configurar Look and Feel:");
            e.printStackTrace();
        }
    }
    

    private static void showFatalError(Exception e) {
        JOptionPane.showMessageDialog(null,
            "Error crítico: " + e.getMessage(),
            "Fallo en la aplicación",
            JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }
}